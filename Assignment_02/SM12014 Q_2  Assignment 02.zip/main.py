# When ‘Stimulate Motion’ is pressed it means the Motion has occurred

from machine import Pin
import utime

led = Pin(12, Pin.OUT)  # pin assigned
pir = Pin(8, Pin.IN, Pin.PULL_UP) # pin assigned 

led.low()  # keep off
utime.sleep(3)  # pause time to process

while True:
   
   print(pir.value())  # print current value
   
   if pir.value() == 1:  # motion detected
      print("MOTION DETECTED")
      print("LED On")
      led.high()
      utime.sleep(5)
   else:  # no motion
      print("Waiting for movement")
      led.low()
      utime.sleep(2)