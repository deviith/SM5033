from machine import Pin
from utime import sleep

# Toggle LED , in every 0.5 sec
print("Integrating LED sensor in Raspberry pi Pico Simulator")

# Initialize the pin 9 
led = Pin(9, Pin.OUT) 

while True:  # Infinite loop
  led.toggle()  # ON OFF toggle function
  sleep(0.5)  # time between ON OFF

